#include "function.h"
const uint16_t X_STP=700, ROT_STP=4600;  //4800


uint8_t temp_x=1, temp_z=1, temp_y=0, temp_pill=0, Door=3, rot=0;
uint8_t rotPcnt=0, rotYcnt=0, rottol_Prot=7, rottol_y=100;

uint32_t time_init=0, time_z=0;

void stperInit(void){
	
	//stepInit(ROT_Y,13000);
	//	startstepper(ROT_Y,1);
	
	
	//HAL_TIM_PWM_Start(&htim17, TIM_CHANNEL_1);
	setdac(ARM_Z);
	while(HAL_GPIO_ReadPin(ARM_Z_STP1_GPIO_Port, ARM_Z_STP1_Pin)){
		printf(";lkdsafsdbcfbvbv %d\n", HAL_GPIO_ReadPin(ARM_Z_STP1_GPIO_Port, ARM_Z_STP1_Pin));
		printf(";------------------ %d\n", HAL_GPIO_ReadPin(ARM_X_STP1_GPIO_Port, ARM_X_STP1_Pin));
		stp = &stepper[ARM_Z];
		startstepper(ARM_Z, 1); //1
		stp->cnt=0;
		if((HAL_GetTick()-time_init)>3000){
			StopStp(ARM_Z);
			protocolActionCallback(moveLimStepperZ,0xFF);
			printf("stepper zzzzzzz timeout!!!!!!!!!!!!!");
			break;
		}
	}
	StopStp(ARM_Z);
	setdacstop(ARM_Z);
	time_init=HAL_GetTick();
	temp_z=1;
	printf(";++++++++++++++++++++++++ %d\n", HAL_GPIO_ReadPin(ARM_X_STP1_GPIO_Port, ARM_X_STP1_Pin));
	while(HAL_GPIO_ReadPin(ARM_X_STP1_GPIO_Port, ARM_X_STP1_Pin)/*&& !HAL_GPIO_ReadPin(ARM_Z_STP1_GPIO_Port, ARM_Z_STP1_Pin)*/){	
		stp = &stepper[ARM_X];
		HAL_GPIO_WritePin(STP1_DIR_GPIO_Port, STP1_DIR_Pin, 1);
		HAL_GPIO_WritePin(STP1_EN_GPIO_Port, STP1_EN_Pin, 1);
		HAL_TIM_PWM_Start(&htim16, TIM_CHANNEL_1);
		stp->cnt=0;
		if((HAL_GetTick()-time_init)>3000){
			HAL_TIM_PWM_Stop(&htim16, TIM_CHANNEL_1);
			protocolActionCallback(moveLimStepperX,0xFF);
			printf("stepper xxxxxxxx timeout!!!!!!!!!!!!!");
			break;
		}		
	}
	HAL_TIM_PWM_Stop(&htim16, TIM_CHANNEL_1);
	temp_x=1;
	time_init=HAL_GetTick();
	//StopStp(ARM_X);
setdac(ROT_Y);
	while(HAL_GPIO_ReadPin(CROT_ENCI_GPIO_Port, CROT_ENCI_Pin)){
		stp = &stepper[ROT_Y];
		
		startstepper(ROT_Y, 1);
		stp->cnt=0;
		//printf("PROT_ENCZ: %d\n", HAL_GPIO_ReadPin(PROT_ENCZ_GPIO_Port, PROT_ENCZ_Pin));
		if((HAL_GetTick()-time_init)>10000){
			StopStp(ROT_Y);
			protocolActionCallback(rotateLimCan,0xFF);
			printf("stepper xxxxxxxx timeout!!!!!!!!!!!!!");
			break;
		}
	}
	StopStp(ROT_Y);
		setdacstop(ROT_Y);
	rotYcnt=0;
	temp_y=0;

	/**/
	
	setdac(rotProt);
		time_init=HAL_GetTick();
	while(HAL_GPIO_ReadPin(PROT_ENCZ_GPIO_Port, PROT_ENCZ_Pin)){
		stp = &stepper[rotProt];
		startstepper(rotProt, 1);
		stp->cnt=0;
		if((HAL_GetTick()-time_init)>30000){

			StopStp(rotProt);
			protocolActionCallback(rotatePillbox,0xFF);
			printf("pillboxtimeout\n");
			break;
		}
	}
	StopStp(rotProt);
	setdacstop(rotProt);
	rotPcnt=0;
	time_init=HAL_GetTick();
	setdac(ChuteDoor);
	while(HAL_GPIO_ReadPin(PILLDR_CLS_GPIO_Port, PILLDR_CLS_Pin)){
		stp = &stepper[ChuteDoor];
		startstepper(ChuteDoor, 1);
		Door=0;
		stp->cnt=0;
		if((HAL_GetTick()-time_init)>30000){
			StopStp(ChuteDoor);
			protocolActionCallback(ctrlChuteDoor,0xFF);
			printf("timeout\n");
			break;
		}
	}
	StopStp(ChuteDoor);
	setdacstop(ChuteDoor);
}

void returnState(void){
	 ARM_Z_dir = 1;
	Door=0;
	if (temp_z ==1){
		ARM_X_dir = 1;
		/*if(temp_x==1 && HAL_GPIO_ReadPin(CROT_ENCI_GPIO_Port, CROT_ENCI_Pin)){
			startstepper(ROT_Y, 1);
		}else if(temp_x==1 ){
			StopStp(ROT_Y);
			temp_y=0;
			protocolActionCallback(rotateLimCan,temp_y+1);
		}else;
	}
	
	if(CDoor==0 && HAL_GPIO_ReadPin(PROT_ENCI_GPIO_Port, PROT_ENCI_Pin)){
			startstepper(rotProt, 1);
		}else if(CDoor==0){
			StopStp(rotProt);
			temp_pill=0;
			protocolActionCallback(rotatePillbox,temp_pill+1);*/
		}else;
		
}

void moveARM_Z(uint8_t dir){
	if(dir){
		
		if(HAL_GPIO_ReadPin(ARM_Z_STP1_GPIO_Port, ARM_Z_STP1_Pin)){
			startstepper(ARM_Z,1);
			temp_z=3;	
		}else if(ARM_Z_dir==1) {
			StopStp(ARM_Z);
			setdacstop(ARM_Z);
			dacZ=0;
			stp = &stepper[ARM_Z];
			stp->cnt=0;
			
			protocolActionCallback(moveLimStepperZ,1);
			
			temp_z=1;
		}
	}else{
		
		if(HAL_GPIO_ReadPin(ARM_Z_STP2_GPIO_Port, ARM_Z_STP2_Pin)){
			startstepper(ARM_Z,0);
			
			temp_z=3;	
		}		else {
			StopStp(ARM_Z);
			setdacstop(ARM_Z);
			dacZ=0;
			
			uint32_t  cnt_z=HAL_GetTick()-time_z;
			uint16_t stp_z=(cnt_z*9600)/1000;
			
			printf("cnt:	%d\n", stp_z);
			protocolActionCallback(moveLimStepperZ, stp_z);
			temp_z=0;		
			
		}
		
	}
	
}

void moveARM_Xptp(uint8_t dir){

	if(dir){
		if(HAL_GPIO_ReadPin(ARM_X_STP1_GPIO_Port, ARM_X_STP1_Pin)){
			HAL_GPIO_WritePin(STP1_DIR_GPIO_Port, STP1_DIR_Pin, 1);
			HAL_GPIO_WritePin(STP1_EN_GPIO_Port, STP1_EN_Pin, 1);
			HAL_TIM_PWM_Start(&htim16, TIM_CHANNEL_1);
		//startstepper(ARM_X,1);
			ismove_x=1;
			temp_x=3;
		}else {
			StopStp(ARM_X);
			protocolActionCallback(moveLimStepperX,1);
			temp_x=1;
			ismove_x=0;
		}
	}else{
		if(HAL_GPIO_ReadPin(ARM_X_STP2_GPIO_Port, ARM_X_STP2_Pin)){
				HAL_GPIO_WritePin(STP1_DIR_GPIO_Port, STP1_DIR_Pin, 0);
			HAL_GPIO_WritePin(STP1_EN_GPIO_Port, STP1_EN_Pin, 1);
			HAL_TIM_PWM_Start(&htim16, TIM_CHANNEL_1);
		//startstepper(ARM_X,0);
			ismove_x=1;
			temp_x=3;
		}		else {
			StopStp(ARM_X);
			protocolActionCallback(moveLimStepperX,0);
			temp_x=0;		
			ismove_x=0;
		}
		
	}
	
}

/**/void moveARM_X(uint16_t stp, uint8_t dir){   //2000 per point
	//printf("stp: %d\n", X_STP*stp);
	stepInit(ARM_X, stp);
	startstepper(ARM_X,dir);
	ismove_x=1;
	protocolActionCallback(ctrlStepperX,stp);
}


void moveROT_Y(uint16_t i, uint8_t dir){
	rottol_y=i;
	rotYcnt=0;
	
	dacY=1;
	ismove_y=1;
	printf("%d, %d", rottol_y, dir) ;
	startstepper(ROT_Y,dir);
	
		
}

void rotateProt(uint32_t i, uint8_t dir){
	printf("stp: %d\n", dir);
	rottol_Prot=i;
	//stepInit(rotProt, i);
	
	dacPill=1;
	rotPcnt=0;
	printf("stp here\n");
	startstepper(rotProt,dir);
	ismove_pill=1;
	//rottol_Prot=i;
}

void chuteDoor (uint8_t dir){
	if(dir){
		if(HAL_GPIO_ReadPin(PILLDR_OPN_GPIO_Port, PILLDR_OPN_Pin)){
		startstepper(ChuteDoor,0);
			Door=3;
		}else {
			StopStp(ChuteDoor);
			setdacstop(ChuteDoor);
			dacDoor=0; 
			protocolActionCallback(ctrlChuteDoor,1);
			printf("hi\n");
			Door=1;
		}
	}else{
		if(HAL_GPIO_ReadPin(PILLDR_CLS_GPIO_Port, PILLDR_CLS_Pin)){
		startstepper(ChuteDoor,1);
			Door=3;
		}	else {
			StopStp(ChuteDoor);
			setdacstop(ChuteDoor);	
			dacDoor=0; 
			protocolActionCallback(ctrlChuteDoor,0);
			Door=0;			
		}
	}
}


void readLimSwitch(void) {
  //dataStream[PILLBX_HALL] = HAL_GPIO_ReadPin(PILLBX_HALL_GPIO_Port, PILLBX_HALL_Pin);
  dataStream[PILLDR_OPN] = HAL_GPIO_ReadPin(PILLDR_OPN_GPIO_Port, PILLDR_OPN_Pin);
  dataStream[PILLDR_CLS] = HAL_GPIO_ReadPin(PILLDR_CLS_GPIO_Port, PILLDR_CLS_Pin);
  //dataStream[PILLBX_DETE] = (uint8_t) VL53L0X_readRangeContinuousMillimeters(&myTOFsensor);
  dataStream[FRNTDR_BUTT] = HAL_GPIO_ReadPin(FRNTDR_BUTT_GPIO_Port, FRNTDR_BUTT_Pin);
  dataStream[FRNTDR_CLS] = HAL_GPIO_ReadPin(FRNTDR_CLS_GPIO_Port, FRNTDR_CLS_Pin);
  
  dataStream[ARM_X_STP1] = HAL_GPIO_ReadPin(ARM_X_STP1_GPIO_Port, ARM_X_STP1_Pin);
  dataStream[ARM_X_STP2] = HAL_GPIO_ReadPin(ARM_X_STP2_GPIO_Port, ARM_X_STP2_Pin);
  dataStream[ARM_Z_STP1] = HAL_GPIO_ReadPin(ARM_Z_STP1_GPIO_Port, ARM_Z_STP1_Pin);
  dataStream[ARM_Z_STP2] = HAL_GPIO_ReadPin(ARM_Z_STP2_GPIO_Port, ARM_Z_STP2_Pin);
  
  dataStream[PROT_ENCI] = HAL_GPIO_ReadPin(PROT_ENCI_GPIO_Port, PROT_ENCI_Pin);
  dataStream[PROT_ENCZ] = HAL_GPIO_ReadPin(PROT_ENCZ_GPIO_Port, PROT_ENCZ_Pin);
  dataStream[CROT_ENCI] = HAL_GPIO_ReadPin(CROT_ENCI_GPIO_Port, CROT_ENCI_Pin);
  dataStream[CROT_ENCZ] = HAL_GPIO_ReadPin(CROT_ENCZ_GPIO_Port, CROT_ENCZ_Pin);
  /*
  printf("PILLBX_HALL: %d\n", dataStream[PILLBX_HALL]);
  printf("PILLDR_OPN: %d\n", dataStream[PILLDR_OPN]);
  printf("PILLDR_CLS: %d\n", dataStream[PILLDR_CLS]);
  printf("PILLBX_DETE: %d\n", dataStream[PILLBX_DETE]);
  
  printf("FRNTDR_BUTT: %d\n", dataStream[FRNTDR_BUTT]);
  printf("FRNTDR_CLS: %d\n",  dataStream[FRNTDR_CLS]);
  printf("ARM_X_STP1: %d\n",  dataStream[ARM_X_STP1]);
  printf("ARM_X_STP2: %d\n",  dataStream[ARM_X_STP2]);
  printf("ARM_Z_STP1: %d\n",  dataStream[ARM_Z_STP1]);
  printf("ARM_Z_STP2: %d\n",  dataStream[ARM_Z_STP2]);
  
  printf("PROT_ENCZ: %d\n", dataStream[PROT_ENCZ]);
  printf("PROT_ENCI: %d\n", dataStream[PROT_ENCI]);
  printf("CROT_ENCI: %d\n", dataStream[CROT_ENCI]);
  printf("CROT_ENCZ: %d\n", dataStream[CROT_ENCZ]);
	*/
}

void readSensors(void) {
  
}

void readNFCSensor (void) {
	uint8_t str[4]={0};
	if (!MFRC522_Request(PICC_REQIDL, str)) {
		printf("here\n");
		if (!MFRC522_Anticoll(str)) {
        printf("MFRC522_Request %x%x%x%x\n", str[0], str[1], str[2], str[3]);
        dataStream[NFC_DATA]=str[0];
				dataStream[NFC_DATA+1]=str[1];
				dataStream[NFC_DATA+2]=str[2];
				dataStream[NFC_DATA+3]=str[3];
		}
	}
}

void test1(){
	rot=1;
	stepInit(ROT_Y,13000);
		startstepper(ROT_Y,0);
}
void test2(){
			while(HAL_GPIO_ReadPin(ARM_Z_STP1_GPIO_Port, ARM_Z_STP1_Pin)){
	stp = &stepper[ARM_Z];
		startstepper(ARM_Z, 1);
		stp->cnt=0;
		//temp_x=0;
	}
	StopStp(ARM_Z);
	
	while(HAL_GPIO_ReadPin(ARM_X_STP1_GPIO_Port, ARM_X_STP1_Pin)){
		stp = &stepper[ARM_X];
		HAL_GPIO_WritePin(STP1_DIR_GPIO_Port, STP1_DIR_Pin, 1);
			HAL_GPIO_WritePin(STP1_EN_GPIO_Port, STP1_EN_Pin, 1);
			HAL_TIM_PWM_Start(&htim16, TIM_CHANNEL_1);
		stp->cnt=0;
		//temp_x=0;
	}HAL_TIM_PWM_Stop(&htim16, TIM_CHANNEL_1);
	
	while(HAL_GPIO_ReadPin(ARM_Z_STP2_GPIO_Port, ARM_Z_STP2_Pin)){
	stp = &stepper[ARM_Z];
		startstepper(ARM_Z, 0);
		stp->cnt=0;
		//temp_x=0;
	}
	StopStp(ARM_Z);
	HAL_GPIO_WritePin(PNEU_PUMP_GPIO_Port, PNEU_PUMP_Pin,1 );
	for(int i=0;i<10;i++){};
	while(HAL_GPIO_ReadPin(ARM_Z_STP1_GPIO_Port, ARM_Z_STP1_Pin)){
	stp = &stepper[ARM_Z];
		startstepper(ARM_Z, 1);
		stp->cnt=0;
		//temp_x=0;
	}
	StopStp(ARM_Z);
	
	
	while(HAL_GPIO_ReadPin(ARM_X_STP2_GPIO_Port, ARM_X_STP2_Pin)){
		stp = &stepper[ARM_X];
		HAL_GPIO_WritePin(STP1_DIR_GPIO_Port, STP1_DIR_Pin, 0);
			HAL_GPIO_WritePin(STP1_EN_GPIO_Port, STP1_EN_Pin, 1);
			HAL_TIM_PWM_Start(&htim16, TIM_CHANNEL_1);
		stp->cnt=0;
		//temp_x=0;
	}HAL_TIM_PWM_Stop(&htim16, TIM_CHANNEL_1);
	
	HAL_GPIO_WritePin(PNEU_PUMP_GPIO_Port, PNEU_PUMP_Pin,0 );
	
	
}

void frontdoor(uint8_t state){
	if( state == 0){
		HAL_GPIO_WritePin(FRNTDR_MAG_GPIO_Port, FRNTDR_MAG_Pin,GPIO_PIN_SET );    //on mag
	}
	else {
		HAL_GPIO_WritePin(FRNTDR_MAG_GPIO_Port, FRNTDR_MAG_Pin,GPIO_PIN_RESET );  //off mag
	}
}





