/*
 * Copyright (c) 2020 PeanutKing Solution
 *
 * @file        protocol.c
 * @summary     Kin pill dispenser stm32 android protocol
 * @version     1.0
 * @author      Jack Kwok
 * @data        1 August 2020
 */



#include "protocol.h"

// Variables
uint8_t addr;

uint8_t dataStream[256];
uint8_t txBuff[50];
uint8_t txBuffLen;
uint8_t rxBuff[10];
uint8_t rxBuffIdx;

uint8_t rxBuffLen;
protocolStatus protocolState;
uint8_t ARM_Z_dir=1, ARM_X_dir=1, isLimit_y=0, CDoor=0,ispick=0, isZero_y=1, isZero_p=1;
uint32_t checktime;
uint8_t funcIdx = 0, Ydir=1, Pdir=1;
int16_t rotate=0;
parameter_t para;

func_t func1[funcListLen] = {
  {ctrlStepperX   , STP_X, 2},
  {ctrlStepperZ   , STP_Z, 2},
  {initrotateCan      , STP_Y, 2},
  {rotatePillbox , STP_PILLBX,  2},
  {ctrlChuteDoor , PNEU_VALV,   1},
  {ctrlPump      , PNEU_PUMP,   1},
  {ctrlLED       , PANEL_LED0,  5},
  {ctrlGate      , FRNTDR_CTRL, 1},
  
  {readAllLimits , PILLBX_HALL, 14},
  {readAllSensors, getMPU6050,  10},
  
  {readNFC       , NFC_DATA,    1},
  {checkPillbox  , PILLBX_DETE, 1},
  {checkGateOpen , FRNTDR_BUTT, 1},
  {checkMachineStatus, STP_X,   1},
  
  {moveLimStepperX, STP_X, 2},
  {moveLimStepperZ, STP_Z, 2},
  {rotateLimCan   , STP_Y, 2},
	
  {ctriticalError , STP_X, 4},
  {movePnP        , STP_X, 4},
  {dispense       , STP_X, 4},
  {pickAndPlace   , STP_X, 4},
	{initpillbox   , STP_X, 0},
	{updateParameter ,STP_X, 8},
  {returnPills ,STP_X, 1},
	
	{autoCheck, STP_X, 1},
	{returnPos   , STP_X, 1},
	{ctrlLEDPattern   , STP_X, 3},
	
	{registerCanister, STP_X, 1},
	{verifyAllCanister, STP_X, 1},
	
	{ctrlValve, STP_Y, 1},
	{frntLock, STP_Y, 1},
	
	
	{batteryoff, STP_Y,0},
};


void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
  
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
  if (huart == &huart2) {
		/**/if(ispick==1){
				
				if (value_adc[0]>700){
					printf("adc0:	%d\n", value_adc[0]);	
					sendctriticalError(pilldrop);
					ispick=0;
				}
			}
    printf("RAW:   %d, \n", rxBuff[0]);
		dataAnalysis();
			
    HAL_UART_Receive_IT(huart, rxBuff, rxBuffLen);
		

  }
}

void sendDataToA33() {
  HAL_UART_Transmit_IT(&huart2, dataStream + func1[funcIdx].r, txBuffLen);
}

void protocolInit(void) {
  protocolState = Idle;
  rxBuffLen = 1;
}

void protocolReset(void) {
  protocolState = Idle;
  rxBuffLen = 1;
}

uint16_t data16[10] = {0};

void protocolActionCallback(uint8_t addr, uint16_t data) {
  txBuff[0] = addr;
	txBuff[1] = data&0xff;
	txBuff[2] = data>>8;
	HAL_UART_Transmit(&huart6, txBuff, 3,1000);
	printf("\n");
  HAL_UART_Transmit_IT(&huart2, txBuff, 3);
  protocolReset();
}
void dataAnalysis(void) {
  uint8_t regAddr = func1[funcIdx].r;
  switch(protocolState) {
    case Idle:
      addr  = rxBuff[0];
      funcIdx = 100;
      for (uint8_t i=0; i<funcListLen; i++) {
				//printf("addr: %d, func1[i].h: %d\n" , addr, func1[i].h);
        if (addr == func1[i].h){
          funcIdx = i;
					//printf(" hi" );
				}
				
      }
		
      if (funcIdx == 100) return;
			
      protocolState = ReceiveData;
      switch(addr) {
				case batteryoff:
					HAL_GPIO_WritePin(PWR_EN_GPIO_Port, PWR_EN_Pin, GPIO_PIN_RESET) ;
				  protocolReset();
					//keepon=0;
        case  readAllLimits:
          readLimSwitch();
          txBuff[0] = addr;
          for (uint8_t i=0; i<func1[funcIdx].l; i++) {
            txBuff[1+i] = dataStream[func1[funcIdx].r+i];
          }
          HAL_UART_Transmit_IT(&huart2, txBuff, func1[funcIdx].l+1);
          protocolReset();
          break;
        case  readAllSensors:
          txBuff[0] = addr;
          for (uint8_t i=0; i<func1[funcIdx].l; i++) {
            txBuff[1+i] = dataStream[func1[funcIdx].r+i];
          }
          HAL_UART_Transmit_IT(&huart2, txBuff, func1[funcIdx].l+1);
          protocolReset();
          break;
        
        case  checkPillbox:   
					protocolState = SendData;
					break;
        case  checkGateOpen:
          data16[0] = rxBuff[0];
          printf("checkGateOpen: %d \n", 1);
          txBuff[0] = addr;
          HAL_UART_Transmit_IT(&huart2, txBuff, 1);
          protocolReset();
          break;
        case  checkMachineStatus:
          printf("checkMachineStatus:\n");
          sendMachineStatus();
          protocolReset();
          break;
				case initpillbox:
					if(ismove_pill==0)
					{	
						if (!HAL_GPIO_ReadPin(PROT_ENCZ_GPIO_Port, PROT_ENCZ_Pin)){
							protocolActionCallback(initpillbox,0);
						}else{
						isZero_p=1;
						setdac(rotProt);
						}
					}else protocolActionCallback(initpillbox,0);
          printf("initpillbox X\n");
					protocolReset();
          break;
      }
      if ( protocolState == ReceiveData ) {
        rxBuffLen = func1[funcIdx].l;
				HAL_UART_Receive(&huart2, rxBuff, rxBuffLen,1000);
				dataAnalysis();
			}
      else if ( protocolState == SendData ) {
        printf("tx: ");
        for (int i=0; i<func1[funcIdx].l; i++) {
          printf("%d, ", dataStream[func1[funcIdx].r+i]);
        }
        printf("\n");
        // ----------------------
        
        
        // send -----------------
        txBuff[0] = addr;
        for (uint8_t i=0; i<func1[funcIdx].l; i++) {
          txBuff[1+i] = dataStream[func1[funcIdx].r+i];
        }
        txBuffLen = func1[funcIdx].l + 1;
        HAL_UART_Transmit_IT(&huart2, txBuff, txBuffLen);
        protocolReset();
      }
      break;
      
    case ReceiveData:
			
      printf("RAW: %x %x %x %x   ", rxBuff[0], rxBuff[1], rxBuff[2], rxBuff[3]);
      switch(addr) {
				case  moveLimStepperX:
          ARM_X_dir = rxBuff[1] ;
          printf("moveLimStepperX: %d \n", ARM_X_dir);
					if(temp_x==ARM_X_dir)  {
						protocolActionCallback(moveLimStepperX,temp_x);
						//HAL_Delay(5);
					}
          break;
				case  moveLimStepperZ:
          ARM_Z_dir = rxBuff[1] ;
          printf("moveLimStepperZ: %d \n", ARM_Z_dir);
          stp = &stepper[ARM_Z];
				
					if(temp_z==ARM_Z_dir)  {
						protocolActionCallback(moveLimStepperZ,stp->cnt);
						printf("2\n");
					}
				time_z=HAL_GetTick();
          break;
				
        case  ctrlStepperX:
          ARM_X_dir = 3 ;
					temp_x=3;
          data16[0] = rxBuff[1] | rxBuff[0] << 8;	
            printf("ctrlStepperX: %d \n", data16[0]);
          if(ismove_x==0){
            moveARM_X(data16[0], 0);
          }else protocolActionCallback(ctrlStepperX, 0);
					//if(temp_x==ARM_X_dir)  protocolActionCallback(ctrlStepperX,temp_x);
          break;
				/**/
				case  initrotateCan:
					data16[0]= rxBuff[1] | rxBuff[0] << 8;
					if(ismove_y==0)
					{	
						if (!HAL_GPIO_ReadPin(CROT_ENCI_GPIO_Port, CROT_ENCI_Pin)){
							protocolActionCallback(initrotateCan,0);
						}else{
						isZero_y=1;
						setdac(ROT_Y);
						}
				
					}else protocolActionCallback(initrotateCan,0);

          printf("initrotateCan X: %d", data16[0]);
          break;
					
        case  rotateLimCan:
					rotate = rxBuff[1] | rxBuff[0] << 8;	
					temp_y=temp_y+rotate;
					if(rotate>0){
						Ydir=1;
					}else  {
						Ydir=0;
						rotate=-rotate;
					}
					
					if(rotate==0){
						 protocolActionCallback(rotateLimCan,temp_y);
					}
					else {
						if(ismove_y==0){
							isLimit_y=1;					
							setdac(ROT_Y);
							HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);
							ismove_y=1;
							moveROT_Y(rotate,!Ydir); 
						}else protocolActionCallback(rotateLimCan,255);
					}
          printf("rotateLimCan lim: %d", rotate);	
					
				
          break;
        case  rotatePillbox:
          rotate = rxBuff[1] | rxBuff[0] << 8;	
					temp_pill=temp_pill+rotate;
					printf("rotatePillbox: %d \n", rotate);
					if(rotate>0){
						Pdir=1;
					}else  {
						Pdir=0;
						rotate=-rotate;
					}
					if(rotate==0)
						 protocolActionCallback(rotatePillbox,temp_pill);
					else {			
						if(ismove_pill==0){
							setdac(rotProt);
							HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);
							rotateProt(rotate, Pdir);
						}else protocolActionCallback(rotatePillbox,0);
					}         		
          break;
						
        case ctrlChuteDoor:
          CDoor = rxBuff[0];	
				printf("%d, %d\n",  CDoor, 	Door);
					if(CDoor==Door){
						protocolActionCallback(ctrlChuteDoor,CDoor);
					}
          printf("ctrlChuteDoor: %d \n", rxBuff[0] );
          break;
					
        case ctrlValve:
          data16[0] = rxBuff[0];
					HAL_GPIO_WritePin(PNEU_VALV_GPIO_Port, PNEU_VALV_Pin,!data16[0] );
          printf("ctrlValve: %d \n", data16[0]);
          break;
				
        case ctrlPump:
          data16[0] = rxBuff[0];
				  checktime=HAL_GetTick();
					HAL_GPIO_WritePin(PNEU_PUMP_GPIO_Port, PNEU_PUMP_Pin,data16[0] );
					HAL_GPIO_WritePin(PNEU_VALV_GPIO_Port, PNEU_VALV_Pin,!data16[0] );
				printf("ctrlPump: %d \n", data16[0]);
				if(data16[0]==1) {
					checkpressure=1;
				}
				 else {
					 checkpressure=0;
					 protocolActionCallback(ctrlPump,1);
				 }
				ispick=0;
          break;
        case ctrlGate:
          data16[0] = rxBuff[0];
          printf("ctrlGate: %d \n", data16[0]);
					HAL_GPIO_WritePin(FRNTDR_MAG_GPIO_Port, FRNTDR_MAG_Pin,data16[0] );
          break;
				
				case frntLock:
					data16[0] = rxBuff[0];
          printf("front door: %d \n", data16[0]);
					HAL_GPIO_WritePin(FRNTDR_LCK_GPIO_Port, FRNTDR_LCK_Pin,GPIO_PIN_SET);
				
				break;
				
				case updateParameter:
					overtemp=rxBuff[1] | rxBuff[0] << 8;
				overroll=rxBuff[3] | rxBuff[2] << 8;
				overpitch=rxBuff[5] | rxBuff[4] << 8;
				overhum=rxBuff[7] | rxBuff[6] << 8;
				break;
				case stopDispense:		
					for(int i=0;i<5;i++){
						StopStp(i);
					}
					break;
				case returnPos:
					data16[0] = rxBuff[0];
					returnstate=data16[0];
					if(returnstate==0){
						StopStp(0);
						StopStp(1);
						StopStp(2);
						StopStp(3);
						StopStp(4);
						ARM_Z_dir= temp_z;
						ARM_X_dir= temp_x;
						CDoor=Door;
					}
				
				break;
					
				case ctrlLEDPattern:   
					printf("ctrlLEDPattern: %d , %d,%d\n", rxBuff[0], rxBuff[1], rxBuff[2]);
					patten[rxBuff[0]]=rxBuff[2];
					
				if(rxBuff[1]==0){ 
					red[rxBuff[0]]=55;
					green[rxBuff[0]]=55;
					blue[rxBuff[0]]=55;
				}
					if(rxBuff[1]==1) {
						red[rxBuff[0]]=55;
						green[rxBuff[0]]=0;
						blue[rxBuff[0]]=0;
					}
					if(rxBuff[1]==2){
						red[rxBuff[0]]=0;
						green[rxBuff[0]]=55;
						blue[rxBuff[0]]=0;
					}
				if(rxBuff[1]==3){
					red[rxBuff[0]]=0;
					green[rxBuff[0]]=0;
					blue[rxBuff[0]]=0;
				}
				
				break;
			
			
			
			case ctrlLED:   //0:led , 1:pattern, 2,3,4:color(r, g, b)
					
				patten[ rxBuff[0]]=rxBuff[1];
				red[rxBuff[0]]=rxBuff[2];
				green[rxBuff[0]]=rxBuff[3];
				blue[rxBuff[0]]=rxBuff[4];
				printf("ctrlLEDPattern: %d , %d, %d\n", rxBuff[2], rxBuff[3], rxBuff[4]);
				printf("ctrlLEDPattern: %d , %d, %d\n", red[rxBuff[0]], green[rxBuff[0]], blue[rxBuff[0]]);
				break;
			case returnPills:
        printf("returnPills: %d \n", rxBuff[0]);
        break;
        
			case  readNFC: 
				printf("readNFC: \n");
				//printf("func1[16].h: %d\n" ,  func1[16].h );
				nfcid=rxBuff[0];
				nfcRead();
				//readNFCSensor();
				nfcid=2;
        txBuff[1] = dataStream[NFC_DATA];
        txBuff[2] = dataStream[NFC_DATA+1];
        txBuff[3] = dataStream[NFC_DATA+2];
        txBuff[4] = dataStream[NFC_DATA+3];
				txBuff[0] =  11; //addr;
				printf("func1[16].h: %d\n" ,  func1[16].h );
				//txBuffLen = 5;
				
				
				HAL_UART_Transmit_IT(&huart2, txBuff, 5);
				protocolReset();
				break;
				
        default:
          printf("default: %d \n", addr);
          
      }
      protocolReset();
      break;
      
    case SendData:
      HAL_UART_Transmit_IT(&huart2, dataStream, txBuffLen);
		
      protocolReset();
      break;
    case SetParameter:
      break;
    default:
      break;
  }
}

void sysTime(void) {
  // on the android side: mmddhhmmyyyy.ss
  // sprintf((char*)dataStream+INT_RTC, "10141905202000");
  
  dataStream[INT_RTC_YEAR]    = gDate.Year;  //     
  dataStream[INT_RTC_MONTH]   = gDate.Month;  //    
  dataStream[INT_RTC_DAY]     = gDate.Date;  //     
  dataStream[INT_RTC_HOUR]    = gTime.Hours;  //     
  dataStream[INT_RTC_MINUTE]  = gTime.Minutes;  //     
  dataStream[INT_RTC_SECOND]  = gTime.Seconds;  //     
}


void sendMachineStatus(void) {
  // gen fake data
 // dataStream[getHDC1080]    = temperature;       //temperature
 // dataStream[getHDC1080+1]  = humidity;       //humid in %
  
  //tiltAngle;
  dataStream[ROLL_H]     = (uint16_t)roll >> 8;
  dataStream[ROLL_L]     = (uint16_t)roll;
  dataStream[PITCH_H]    = (uint16_t)pitch >> 8;
  dataStream[PITCH_L]    = (uint16_t)pitch;
  
  sysTime();
  
  txBuff[0] = checkMachineStatus;
  txBuff[1] = dataStream[getHDC1080];   //temperature
  txBuff[2] = dataStream[getHDC1080+1]; //humid
  txBuff[3] = dataStream[ROLL_H];   //tiltAngle;
   txBuff[4] = dataStream[ROLL_L]; 
	 txBuff[5] = dataStream[PITCH_H]; 
	 txBuff[6] = dataStream[PITCH_L]; 
  for (uint8_t i=0; i<6; i++) {
    txBuff[7+i] = dataStream[INT_RTC_YEAR+i];
  }
//  HAL_UART_Transmit(&huart6, txBuff, 10,1000);
	/*txBuff[10]=dataStream[FRNTDR_CLS];
	txBuff[11]=dataStream[FRNTDR_BUTT];
	txBuff[12]=dataStream[PILLBX_DETE];
	
  txBuff[13] = 2;                    */   //firmwareVer
  HAL_UART_Transmit_IT(&huart2, txBuff, 13);
}

//sprintf((char*)time,"%02d:%02d:%02d\n",gTime.Hours, gTime.Minutes, gTime.Seconds);
/* Display date Format: dd-mm-yy */
//sprintf((char*)date,"%02d-%02d-%2d",gDate.Date, gDate.Month, 2000 + gDate.Year);

void sendLimSwitchToA33(void) {
  readLimSwitch();
  txBuff[0] = readAllLimits;
  for (uint8_t i=0; i<14; i++) {
    txBuff[1+i] = dataStream[PILLBX_HALL+i];
  }
  HAL_UART_Transmit_IT(&huart2, txBuff,14+1);
	//HAL_UART_Transmit(&huart6, txBuff,14+1, 1000);
	//printf("\n");
}

void sendctriticalError(errorCode_t er) {
  txBuff[0] = ctriticalError;
  txBuff[1] = er;
	//printf(" error:  %d" , er);
  HAL_UART_Transmit(&huart2, txBuff, 2,100);
}

/*
  errorCriteriaTable
  -	Over temperature 40? Celsius
  -	Tilted over 20?
  -	Humidity level over 70%
  -	No pillbox (feedback by any Process API)
  -	NFC tag wrong OR Null (feedback by Process API)
  -	Retry failed (feedback by Process API)
*/

void updateParameterTable(void) {
  para.temp = rxBuff[0];
  para.tilt = rxBuff[1];
  para.humi = rxBuff[2];
  for(uint8_t i; i<5; i++) {
    para.x[i] = rxBuff[3+i];
  }
  for(uint8_t i; i<5; i++) {
    para.y[i] = rxBuff[8+i];
  }
}

void errorCriteriaTable(void) {
  txBuff[0] = 0;
  txBuff[1] = temp;
  txBuff[2] = dataStream[getHDC1080];
  txBuff[3] = 0;//noPillbox;
  txBuff[4] = dataStream[NFC_DATA];
  txBuff[5] = dataStream[NFC_DATA+1];
  txBuff[6] = dataStream[NFC_DATA+2];
  txBuff[7] = dataStream[NFC_DATA+3];
  //txBuff[5] = RetryFailed;
  HAL_UART_Transmit_IT(&huart2, txBuff, 8);
	 protocolReset();
}





