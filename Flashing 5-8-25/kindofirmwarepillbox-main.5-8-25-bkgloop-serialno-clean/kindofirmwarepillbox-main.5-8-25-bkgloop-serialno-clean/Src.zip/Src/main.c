/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "rtc.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* RTC_DateTypeDef gDate; 
 RTC_TimeTypeDef gTime; 

struct rtc_time
{
	int tm_sec;
	int tm_min;
	int tm_hour;
	int tm_mday;
	int tm_mon;
	int tm_year;
	int tm_wday;
};

struct rtc_time rtc_time;
uint8_t time[10];
uint8_t date[10];

*/

    


uint32_t value_adc[12];
uint32_t lasttime=0, pwtime=0, piltime=0, rottime=0;
uint8_t isonb=0, batterydet=0;
uint8_t isinit1080, isinitMPU6050,mpuerror=0,hdcerror=0;
uint8_t targ_x,targ_z, mcuinit=0, checkpressure=0, checkstate[10],ismove_x=0,ismove_y=0,ismove_pill=0,returnstate=0;
uint8_t patten[3]={0},red[3]={0}, green[3]={0}, blue[3]={0} , white[3]={0};
uint16_t overtemp=80, overroll=150, overpitch=30, overhum=50;
uint8_t dacZ=0,	dacY=0, dacPill=0, dacDoor=0; 
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

uint8_t ch;
uint8_t ch_r;
uint16_t adc_8;

int fputc(int c, FILE * f) {
  ch=c;
  HAL_UART_Transmit(&huart6, &ch, 1, 1000);
  return c;
}

int fgetc(FILE * F) {
  HAL_UART_Receive(&huart6, &ch_r, 1, 1000);
  return ch_r;
}

void __delay_ms(int32_t k)
{
	int32_t i,j ;
	for(i=0;i<k;i++)
		for(j=0;j<3000;j++)
		{
			//printf(" hi \n");
		}
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void setXYstp(uint16_t X, uint16_t Y){
	/*if(!HAL_GPIO_ReadPin(ARM_X_STP1_GPIO_Port, ARM_X_STP1_Pin)){
		stepInit(ARM_Y,12800);
		startstepper(ARM_Y,1);
	}else if(HAL_GPIO_ReadPin(ARM_X_STP2_GPIO_Port, ARM_X_STP2_Pin)){
		startstepper(ARM_X,1);
		while(HAL_GPIO_ReadPin(ARM_X_STP2_GPIO_Port, ARM_X_STP2_Pin));
		HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);
	}*/
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
	if(htim==&htim6){
		 // Breath(55,0,0);
		if(patten[0]== change){
			
			Breath(red[0], green[0], blue[0]);
		}
		MadgwickAHRSupdateIMU(xGyro, yGyro, zGyro, xAccl, yAccl, zAccl);
		//printf("%d\n", HAL_GetTick());
	}
	if(htim == &htim1){
		stp = &stepper[3];
		stp->cnt++;
		//stepCtrl(3);
		//debug
	   
	}
	//printf("hi\n");
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc) {
	adc_8 = value_adc[1];
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC_Init();
  MX_I2C2_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  MX_TIM14_Init();
  MX_TIM15_Init();
  MX_TIM16_Init();
  MX_TIM17_Init();
  MX_RTC_Init();
  MX_SPI1_Init();
  MX_SPI2_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_USART6_UART_Init();
  MX_TIM6_Init();
  MX_USART4_UART_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
	
	//HAL_GPIO_WritePin(PNEU_PUMP_GPIO_Port, PNEU_PUMP_Pin,GPIO_PIN_RESET );
	//HAL_GPIO_WritePin(PNEU_VALV_GPIO_Port, PNEU_VALV_Pin,GPIO_PIN_RESET );
	//HAL_GPIO_WritePin(FRNTDR_MAG_GPIO_Port, FRNTDR_MAG_Pin,GPIO_PIN_RESET );
	//HAL_GPIO_WritePin(FRNTDR_LCK_GPIO_Port, FRNTDR_LCK_Pin,GPIO_PIN_RESET );
	
	HAL_NVIC_DisableIRQ(EXTI4_15_IRQn);
	
	//pressure sensor
	HAL_ADC_Start_DMA(&hadc, (uint32_t*)value_adc, 5);
	
	//power mode
	HAL_GPIO_WritePin(PWR_EN_GPIO_Port, PWR_EN_Pin, GPIO_PIN_RESET) ;
	HAL_GPIO_WritePin(A33_PWR_GPIO_Port, A33_PWR_Pin, GPIO_PIN_SET) ;

	//mpu6050
	HAL_TIM_Base_Start_IT(&htim6);
	isinitMPU6050=mpu6050Init();
	printf("init\n");
	
	//HDC1080 
	isinit1080=HDC1080_Init();
	
	
	//vl53l0x
	VL53L0X myTOFsensor = { .io_2v8 = 2, .address = 83, .io_timeout = 500  };
	VL53L0X_init(&myTOFsensor);
	VL53L0X_setMeasurementTimingBudget(&myTOFsensor, 200000);
	VL53L0X_startContinuous(&myTOFsensor, 0);
	
	
	//rc522
	MFRC522_Init();
	printf("init2\n");

	//led
	for(int i=0; i<24; i++) led_set_RGB(i,0,0,0);
	//led_set_all_RGB(25, 0,0) ;
	led_render();
	printf("init_LED\n");
	
	//stepper
	//setAlldac();
	/**/for(int i=0;i<5;i++){
		setdacstop(i);
	}
	setdac(ARM_X);
	stperInit();

	printf("init_stper\n");

	protocolInit();
	printf("init_protocol\n");

	
 /*while (1)
  {
		
		HAL_Delay(300);
	}*/

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
			
		if(batterydet==1 && HAL_GetTick()-pwtime>1000){
			//HAL_Delay(500);
		/**/	printf(" battery!!!!!!!!!!!!!!!!!!!\n");	
			if(isonb==1/*HAL_GPIO_ReadPin(DCIN_DET_GPIO_Port, DCIN_DET_Pin)==RESET*/){
			
			printf("!!!!!!!!!!no battery!!!!!!!!!!!!!!!!!!!\n");		
			HAL_GPIO_WritePin(PWR_EN_GPIO_Port, PWR_EN_Pin, GPIO_PIN_SET);
			sendctriticalError(battery);
			isonb=1;
			if(value_adc[0]<=800){
				HAL_GPIO_WritePin(PNEU_PUMP_GPIO_Port, PNEU_PUMP_Pin,1 );
				HAL_GPIO_WritePin(PNEU_VALV_GPIO_Port, PNEU_VALV_Pin,0 );
				
			}
			pwtime=HAL_GetTick();
		}else {
			HAL_GPIO_WritePin(PWR_EN_GPIO_Port, PWR_EN_Pin, GPIO_PIN_RESET);
			sendctriticalError(battery);
			printf("!!!!!!!!!!hi hi hi hi  battery!!!!!!!!!!!!!!!!!!!\n");		
			isonb=0;
			mcuinit=1;
			
		}
		batterydet=0;
		}
		if(mcuinit==1){
			HAL_Delay(5000);
			//setAlldac();
			ARM_Z_dir=1;
			ARM_X_dir=1;
			isLimit_y=0; 
			CDoor=0;
			ispick=0;
			isZero_y=1;
			isZero_p=1;
			setdac(ARM_X);
			
			
			stperInit();
			printf("jerho//////////////");
			isinitMPU6050=mpu6050Init();
			isinit1080= HDC1080_Init();
			mcuinit=0;
		}
		
	if(isonb==0){
			if(value_adc[3]<255) {
				printf("------------------battery----bye-------------");
		    HAL_GPIO_WritePin(PWR_EN_GPIO_Port, PWR_EN_Pin, GPIO_PIN_SET);
				isonb=1;
				batterydet=1 ;
			}
			
		}
	if(isonb==1){
			if(value_adc[3]>500) {
				printf("------------------battery----here-------------");
		    HAL_GPIO_WritePin(PWR_EN_GPIO_Port, PWR_EN_Pin, GPIO_PIN_RESET);
				isonb=0;
				batterydet=1;
			}
			
		}

		
				/**/
		/*if(keepon ==1){
			__disable_irq();
			//can close some motor
			HAL_GPIO_WritePin(PWR_EN_GPIO_Port, PWR_EN_Pin, GPIO_PIN_SET) ;
			uint32_t time_init=HAL_GetTick();
			printf("%d : ", HAL_GPIO_ReadPin(ARM_Z_STP1_GPIO_Port, ARM_Z_STP1_Pin));
			while(HAL_GPIO_ReadPin(ARM_Z_STP1_GPIO_Port, ARM_Z_STP1_Pin)){
				stp = &stepper[ARM_Z];
				startstepper(ARM_Z, 1);
				stp->cnt=0;
				if((HAL_GetTick()-time_init)>3000){
					StopStp(ARM_Z);
					//protocolActionCallback(moveLimStepperZ,0xFF);
					printf("timeout");
					break;
				}
			}
			StopStp(ARM_Z);
			time_init=HAL_GetTick();
			temp_z=1;
			ARM_Z_dir=1;
			
			while(HAL_GPIO_ReadPin(ARM_X_STP1_GPIO_Port, ARM_X_STP1_Pin)){
				stp = &stepper[ARM_X];
				HAL_GPIO_WritePin(STP1_DIR_GPIO_Port, STP1_DIR_Pin, 1);
				HAL_GPIO_WritePin(STP1_EN_GPIO_Port, STP1_EN_Pin, 1);
				HAL_TIM_PWM_Start(&htim16, TIM_CHANNEL_1);
				stp->cnt=0;
				if((HAL_GetTick()-time_init)>3000){
					HAL_TIM_PWM_Stop(&htim16, TIM_CHANNEL_1);
					//protocolActionCallback(moveLimStepperX,0xFF);
					break;
				}
			}
			HAL_TIM_PWM_Stop(&htim16, TIM_CHANNEL_1);
			temp_x=1;
			ARM_X_dir=1;
			HAL_GPIO_WritePin(PNEU_PUMP_GPIO_Port, PNEU_PUMP_Pin,0 );
			HAL_GPIO_WritePin(PNEU_VALV_GPIO_Port, PNEU_VALV_Pin,1 );
			__enable_irq();
			if(HAL_GetTick()-pwtime>5000){
				//HAL_GPIO_WritePin(PWR_EN_GPIO_Port, PWR_EN_Pin, GPIO_PIN_RESET) ;
				keepon=0;
			}
			 
		}*/
		if(returnstate==1){
			returnState();
		}
		
	
		
		//rtc
		get_time();
		  
		
		
		
		
		
		
		
		//hadc1080
	

		dataStream[FRNTDR_CLS]= !HAL_GPIO_ReadPin(FRNTDR_CLS_GPIO_Port, FRNTDR_CLS_Pin);
		

		
		
		
		if(value_adc[1]<20){
			sendctriticalError(nopillbox);
		}
		
		
		
		//led	
	

	
		
	
		//loopblink(TWOLED, 55, 0,  0 ,  0, 2,100);
		if(patten[1]==blink){
			loopblink(TWOLED, red[1], green[1], blue[1] , white[1], 2,500);
			
		}
		if(patten[2]==blink){
			loopblink(3, red[2], green[2], blue[2] , white[2], 1,500);
		}	
		if(patten[0]==longon){
			led_set_all_RGB(red[0], green[0], blue[0]) ;
			led_render();
			patten[0]=255;
		}
		if(patten[1]==longon){
			loopledSetRgb(RLED, red[1], green[1], blue[1] , white[1], 2);
			loopledSetRgb(LLED, red[1], green[1], blue[1] , white[1], 2);
		}
		if(patten[2]==longon){
			loopledSetRgb(2, red[2], green[2], blue[2] , white[2], 2);	
		}

		if( checkpressure ==1){
			
			if (value_adc[0]<=800 && (HAL_GetTick()-checktime)<=1000 ){
				HAL_Delay(1);
				protocolActionCallback(ctrlPump,1);
				
				checkpressure =0;
				ispick=1;
			}else if((HAL_GetTick()-checktime)>1000 ){
				protocolActionCallback(ctrlPump,255);
				checkpressure =0;
				
			}
		}
			
			

		//stper
	/**/		
		if(ARM_Z_dir!= temp_z || (ARM_Z_dir==1 && HAL_GPIO_ReadPin(ARM_Z_STP1_GPIO_Port, ARM_Z_STP1_Pin)==1)){
			
			if(dacZ==0) {
				setdac(ARM_Z);
				dacZ=1;
			}
			moveARM_Z(ARM_Z_dir);
		}	
	if(CDoor!=Door||(CDoor==0 && HAL_GPIO_ReadPin(PILLDR_CLS_GPIO_Port, PILLDR_CLS_Pin)==1)||(CDoor==1&&(HAL_GPIO_ReadPin(PILLDR_OPN_GPIO_Port, PILLDR_OPN_Pin)==1))){
		printf("%d, %d\n",  CDoor, 	Door);
			if(dacDoor==0) {
				setdac(ChuteDoor);
				dacDoor=1;
			}
			chuteDoor(CDoor);
			//printf(" Door: %d, CDoor: %d",Door, CDoor);
		}
		if(ARM_X_dir!= temp_x || (ARM_X_dir==1 && HAL_GPIO_ReadPin(ARM_X_STP1_GPIO_Port, ARM_X_STP1_Pin)==1)||(ARM_X_dir==0 && HAL_GPIO_ReadPin(ARM_X_STP2_GPIO_Port, ARM_X_STP2_Pin)==1)){
			moveARM_Xptp(ARM_X_dir);
		}
		 
		if(isZero_y ){
			time_init=HAL_GetTick();
			setdac(ROT_Y);
			while(HAL_GPIO_ReadPin(CROT_ENCI_GPIO_Port, CROT_ENCI_Pin)){      
					stp = &stepper[ROT_Y];
		
					startstepper(ROT_Y, 1);
					stp->cnt=0;
		//printf("PROT_ENCZ: %d\n", HAL_GPIO_ReadPin(PROT_ENCZ_GPIO_Port, PROT_ENCZ_Pin));
			if((HAL_GetTick()-time_init)>10000){
					StopStp(ROT_Y);
					protocolActionCallback(initrotateCan,0);
					printf("stepper xxxxxxxx timeout!!!!!!!!!!!!!");
					break;
					}
			}
				StopStp(ROT_Y);
				setdacstop(ROT_Y);
				rotYcnt=0;
				temp_y=0;
				isZero_y=0;
				protocolActionCallback(initrotateCan,0);
			// no while loop, the rotation will be slow. ** replace the above code if don't want to use while **  //
			/*
			if(HAL_GPIO_ReadPin(CROT_ENCI_GPIO_Port, CROT_ENCI_Pin)){
				assignstepper(ROT_Y, 15);
			startstepper(ROT_Y, 1);
			}else {
				StopStp(ROT_Y);
				setdacstop(ROT_Y);
				assignstepper(ROT_Y, 5);
				isZero_y=0;
				protocolActionCallback(initrotateCan,0);
				temp_y=0;
			}*/
		}
		
		if(isZero_p){
			if(HAL_GPIO_ReadPin(PROT_ENCZ_GPIO_Port, PROT_ENCZ_Pin)){
			startstepper(rotProt, 1);
			}else {
				StopStp(rotProt);
				setdacstop(rotProt);
				isZero_p=0;
				protocolActionCallback(initpillbox,0);
				temp_pill=0;
			}
		}
		
		if(dacY==1 && ismove_y==0){
			setdacstop(ROT_Y);
			dacY=0;
		}
		if(dacPill==1 && ismove_pill==0){
			setdacstop(rotProt);
			dacPill=0;
		}
		//printf(" hi \n");
		//printf(" %d \n", HAL_GetTick());
			//andriod
		HAL_UART_Receive_IT(&huart2, rxBuff, rxBuffLen);
		
		if(HAL_GetTick()-lasttime>1000){
			//printf(" %d \n", HAL_GetTick()-lasttime);
			//printf(" hi          hi           hi \n");
			lasttime=HAL_GetTick();
			
	//VL53L0X		
			if(VL53L0X_readRangeContinuousMillimeters(&myTOFsensor)<150){
			dataStream[PILLBX_DETE]=1; 
		}else{ 
			dataStream[PILLBX_DETE]=0;
		}
	 
			sendLimSwitchToA33();	
			
			
			
				if(patten[0]==blink){
			BlinkLed(red[0], green[0], blue[0]);
		}
			/*nfcid=2;			
			if(!nfcRead()){
				//sendctriticalError(nopillbox);
			}*/
			//printf("%d\n", ismove_y);
			if(ismove_y==3){
				
				setdacstop(ROT_Y);
				protocolActionCallback(rotateLimCan, temp_y);
				ismove_y=0;
			}
			
			if(ismove_pill==3){
				setdacstop(rotProt);
				ismove_pill=0;
			}
			
			
			//mpu6050
	
		/**/
		if(!isinitMPU6050){
			isinitMPU6050=mpu6050Init();
		}else if(WhoAmIMPU()!=0x68){
			mpuerror=1;
		}else if(mpuerror == 1){
			isinitMPU6050=mpu6050Init();
		}else {
			mpu6050GetAllReading();
			
			if(pitch>overpitch || pitch <-overpitch || (roll<-overroll && roll>overroll)){
				sendctriticalError(tilted);
			}
		}
			
				/**/if(!isinit1080){
			isinit1080= HDC1080_Init();
		}else if(!WhoAmIHDC()){
			hdcerror=1;
		}else if(hdcerror==1 && !WhoAmIHDC()){
			isinit1080= HDC1080_Init();
		}else{
			HADC1080_Display();
		}
		if(dataStream[getHDC1080]>overtemp){
			sendctriticalError(overTemp);		
		}
		if(dataStream[getHDC1080+1]>overhum){
			sendctriticalError(overHumid);		
		}
		
		
			
			//debug
			
			//switch
			/*
			HAL_GPIO_WritePin(PNEU_PUMP_GPIO_Port, PNEU_PUMP_Pin,GPIO_PIN_SET);
			HAL_GPIO_WritePin(PNEU_VALV_GPIO_Port, PNEU_VALV_Pin,GPIO_PIN_SET);
			HAL_GPIO_WritePin(FRNTDR_MAG_GPIO_Port, FRNTDR_MAG_Pin,GPIO_PIN_SET);
			HAL_GPIO_WritePin(FRNTDR_LCK_GPIO_Port, FRNTDR_LCK_Pin,GPIO_PIN_SET);
			*/
			
			
			//adc
		 
			/*
			printf("adc2:	%d(%f)\n", value_adc[2], value_adc[2]*6/51/0.05);   //current of sys_5V
			printf("adc0:	%d\n", value_adc[0]);																//pressure sensor
			printf("adc1:	%d\n", value_adc[1]);																//pillbox detect
			printf("adc3:	%d\n", value_adc[3]);
			printf("adc4:	%d\n", value_adc[4]);
			*/
		
			//senser
			
			/*
			printf("PILLBX_HALL: %d\n", HAL_GPIO_ReadPin(PILLBX_HALL_GPIO_Port, PILLBX_HALL_Pin));
			printf("PROT_ENCZ: %d\n", HAL_GPIO_ReadPin(PROT_ENCZ_GPIO_Port, PROT_ENCZ_Pin));
			printf("PROT_ENCI: %d\n", HAL_GPIO_ReadPin(PROT_ENCI_GPIO_Port, PROT_ENCI_Pin));
			printf("CROT_ENCI: %d\n", HAL_GPIO_ReadPin(CROT_ENCI_GPIO_Port, CROT_ENCI_Pin));
			printf("CROT_ENCZ: %d\n", HAL_GPIO_ReadPin(CROT_ENCZ_GPIO_Port, CROT_ENCZ_Pin));
			printf("ARM_Z_STP1: %d\n", HAL_GPIO_ReadPin(ARM_Z_STP1_GPIO_Port, ARM_Z_STP1_Pin));
			printf("ARM_Z_STP2: %d\n", HAL_GPIO_ReadPin(ARM_Z_STP2_GPIO_Port, ARM_Z_STP2_Pin));
			printf("FRNTDR_BUTT: %d\n", HAL_GPIO_ReadPin(FRNTDR_BUTT_GPIO_Port, FRNTDR_BUTT_Pin));
			printf("FRNTDR_CLS: %d\n", HAL_GPIO_ReadPin(FRNTDR_CLS_GPIO_Port, FRNTDR_CLS_Pin));
			printf("PILLDR_OPN: %d\n", HAL_GPIO_ReadPin(PILLDR_OPN_GPIO_Port, PILLDR_OPN_Pin));
			printf("PILLDR_CLS: %d\n", HAL_GPIO_ReadPin(PILLDR_CLS_GPIO_Port, PILLDR_CLS_Pin));
			printf("PILLBX_DET: %d\n", HAL_GPIO_ReadPin(PILLBX_DET_GPIO_Port, PILLBX_DET_Pin));
			printf("ARM_X_STP1: %d\n", HAL_GPIO_ReadPin(ARM_X_STP1_GPIO_Port, ARM_X_STP1_Pin));	
			printf("ARM_X_STP2: %d\n", HAL_GPIO_ReadPin(ARM_X_STP2_GPIO_Port, ARM_X_STP2_Pin));
			printf("DCIN_DET: %d\n", HAL_GPIO_ReadPin(DCIN_DET_GPIO_Port, DCIN_DET_Pin));
			printf("PWR_EN: %d\n", HAL_GPIO_ReadPin(PWR_EN_GPIO_Port, PWR_EN_Pin));
			*/
			
			//temp & humi
			/*
			printf("temp = %d\n", dataStream[getHDC1080] );
			printf("humi = %d\n", dataStream[getHDC1080+1]);	
			*/
			
			//mpu6050
			/*
			mpu6050Display();
			printf("overroll: %d\n", overroll);
			*/
			//real time clock
			/*
			displaytime();
			*/
				
				
			//nfc
			/*
					nfcid=2;
			
					nfcRead();
					
			*/
		}
		
	}

		
		
		
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI
                              |RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1|RCC_PERIPHCLK_USART2
                              |RCC_PERIPHCLK_I2C1|RCC_PERIPHCLK_RTC;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
  /** Enables the Clock Security System 
  */
  HAL_RCC_EnableCSS();
}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
	
	if ( GPIO_Pin == DCIN_DET_Pin && HAL_GetTick()-pwtime>1000){
		pwtime=HAL_GetTick();
		batterydet=1;
		printf("------------------battery--------------------");
		HAL_GPIO_WritePin(PWR_EN_GPIO_Port, PWR_EN_Pin, GPIO_PIN_SET);
		//if(isonb==0) HAL_GPIO_WritePin(PWR_EN_GPIO_Port, PWR_EN_Pin, GPIO_PIN_SET);
		//else HAL_GPIO_WritePin(PWR_EN_GPIO_Port, PWR_EN_Pin, GPIO_PIN_RESET);
		
	}/*
		if(GPIO_Pin == PILLDR_CLS_Pin){
		  printf("%d	%d\n", rotPcnt++, HAL_GPIO_ReadPin(PILLDR_CLS_GPIO_Port, PILLDR_CLS_Pin));
			if(rotPcnt>30)rotPcnt=0;
		}*/
	
	if(GPIO_Pin == PROT_ENCI_Pin &&  HAL_GetTick()-piltime>1000){
		piltime=HAL_GetTick();
		if(ismove_pill==1){
			rotPcnt++;
		}else;
		//printf("cnt: %d\n time:	%d\n",rotPcnt, piltime);
		if(rotPcnt>=rottol_Prot+1){
			StopStp(rotProt);
			
			printf("end\n");
			HAL_NVIC_DisableIRQ(EXTI4_15_IRQn);
			protocolActionCallback(rotatePillbox,temp_pill);
			
			ismove_pill=3;
			rotPcnt=0;
		}
	}/**/
		/**/
		if(GPIO_Pin == CROT_ENCZ_Pin && HAL_GetTick()-rottime>70){
			rottime=HAL_GetTick();
			printf("cnt: %d\n time:	%d\n",rotYcnt, rottime);
			if(ismove_y==1){
			rotYcnt++;
		}else;
			if(rotYcnt>=rottol_y+1){
				StopStp(ROT_Y);
				printf("end");
				HAL_NVIC_DisableIRQ(EXTI4_15_IRQn);
				
				ismove_y=3;
				rotYcnt=0;
				rottol_y=0;
		
			}
		}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
