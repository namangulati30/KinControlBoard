// Peripheral usage
#include "stm32f0xx_hal.h"

#include "sk6812.h"

#define PWM_HI (38)
#define PWM_LO (19)
 

// LED parameters
 #define NUM_BPP (3) // WS2812B
//#define NUM_BPP (4) // SK6812
#define NUM_PIXELS (24) //(25)
#define NUM_BYTES (NUM_BPP * NUM_PIXELS)

// LED color buffer
uint8_t rgb_arr[NUM_BYTES] = {0};
int8_t angle = 0;
const uint8_t angle_difference = 11;
// LED write buffer
#define WR_BUF_LEN (NUM_BPP * 8 * 2)
volatile uint8_t wr_buf[WR_BUF_LEN] = {0};
uint_fast8_t wr_buf_p = 0;
uint32_t ledtime;
uint8_t RLstate=1, LLstate=1, Lstate3=1;
uint8_t state=0;
static inline uint8_t scale8(uint8_t x, uint8_t scale) {
  return ((uint16_t)x * scale) >> 8;
}
void ledinit(void){
	HAL_TIM_PWM_Start_IT(&htim3, TIM_CHANNEL_4);
}

// Set a single color (RGB) to index
void led_set_RGB(uint8_t index, uint8_t r, uint8_t g, uint8_t b) {
#if (NUM_BPP == 4) // SK6812
  rgb_arr[4 * index] = scale8(g, 0xB0); // g;
  rgb_arr[4 * index + 1] = r;
  rgb_arr[4 * index + 2] = scale8(b, 0xF0); // b;
  rgb_arr[4 * index + 3] = 0;
#else // WS2812B
  rgb_arr[3 * index] = g;//scale8(g, 0xB0); // g;
  rgb_arr[3 * index + 1] = r;
  rgb_arr[3 * index + 2] = b;//scale8(b, 0xF0); // b;
#endif // End SK6812 WS2812B case differentiation
}

// Set a single color (RGBW) to index
void led_set_RGBW(uint8_t index, uint8_t r, uint8_t g, uint8_t b, uint8_t w) {
  led_set_RGB(index, r, g, b);
#if (NUM_BPP == 4) // SK6812
  rgb_arr[4 * index + 3] = w;
#endif // End SK6812 WS2812B case differentiation
}

// Set all colors to RGB
void led_set_all_RGB(uint8_t r, uint8_t g, uint8_t b) {
  for(uint_fast8_t i = 0; i < NUM_PIXELS; ++i) led_set_RGB(i, r, g, b);
}

// Set all colors to RGBW

void loopledSetRgb(uint8_t group, uint8_t r, int8_t g,int8_t b,int8_t w, uint8_t n) {
	uint8_t LED0_H = 1;     // 0.4 us * 48/4
	uint8_t LED0_L = 1;    // 0.9 us * 48/4
	uint8_t LED1_H = 1;     // 0.6 us * 48/4
	uint8_t LED1_L = 1; 
  uint_fast8_t
    i = 4,
    j = 8,
    k = 0,
    hCycle = 0,
    lCycle = 0;
  uint8_t led[4] = {b,r,g,w};
  
  uint_fast8_t H[4*8], L[4*8];
  
  for (i=0; i<4; i++) {
    for (j=0; j<8; j++) {
      if( led[i]&(1<<j) ) {
       H[k]=1;
      }
      else {
        H[k] = 0;
       
      }
      k++;
    }
  }
  
  __disable_irq();
  switch (group){
    case RLED:
	
		k=24;
	
	while (n--){
		
  while(k--){   
			if (H[k]==1){				// takes 4 cycle
				
        GPIOC->BSRR = (uint32_t)GPIO_PIN_8;              // SET HIGH
        __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
        GPIOC->BRR = (uint32_t)GPIO_PIN_8;
         __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				
      }
		    else if(H[k]==0) {              // takes 4 cycle
        GPIOC->BSRR = (uint32_t)GPIO_PIN_8;              // SET HIGH
        __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
        GPIOC->BRR = (uint32_t)GPIO_PIN_8;
        __nop();__nop();__nop();__nop();__nop();
					 __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
					 __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
      }
				 
		}
	k=24;
	}
    break;
    case LLED:
				k=24;
	
	while (n--){
		
  while(k--){   
			if (H[k]==1){				// takes 4 cycle
				
        GPIOC->BSRR = (uint32_t)GPIO_PIN_7;              // SET HIGH
        __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
        GPIOC->BRR = (uint32_t)GPIO_PIN_7;
         __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				
      }
		    else if(H[k]==0) {              // takes 4 cycle
        GPIOC->BSRR = (uint32_t)GPIO_PIN_7;              // SET HIGH
        __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
        GPIOC->BRR = (uint32_t)GPIO_PIN_7;
        __nop();__nop();__nop();__nop();__nop();
					 __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
					 __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
      }
				 
		}
	k=24;
	}
     
    break;
    case LED3:
						k=24;
	
	//while (n--){
		
  while(k--){   
			if (H[k]==1){				// takes 4 cycle
				
        GPIOC->BSRR = (uint32_t)GPIO_PIN_6;              // SET HIGH
        __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
        GPIOC->BRR = (uint32_t)GPIO_PIN_6;
         __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				
      }
		    else if(H[k]==0) {              // takes 4 cycle
        GPIOC->BSRR = (uint32_t)GPIO_PIN_6;              // SET HIGH
        __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
        GPIOC->BRR = (uint32_t)GPIO_PIN_6;
        __nop();__nop();__nop();__nop();__nop();
					 __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
					 __nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
				__nop();__nop();__nop();__nop();__nop();
      }
			
		}
	k=24;
	//}

    break;
  }
  __enable_irq();
}

void loopblink(uint8_t group, uint8_t r, int8_t g,int8_t b,int8_t w, uint8_t n, uint16_t time){
	if((HAL_GetTick()-ledtime)>time){
		
	
	switch(group){
		
		case TWOLED:
	if(RLstate==1){
			loopledSetRgb(RLED, r, g, b, w, n);
			loopledSetRgb(LLED, r, g, b, w, n);
	RLstate=0;
	}
	else{
		loopledSetRgb(RLED, 0,0,0,0, n);
		loopledSetRgb(LLED, 0,0,0,0, n);
		RLstate=1;
	}	
	case LED3:
	if(Lstate3==1){
	loopledSetRgb(group, r, g, b, w, n);
	Lstate3=0;
	}
	else{
		loopledSetRgb(group, 0,0,0,0, n);
		Lstate3=1;
		}
	}
	ledtime=HAL_GetTick();
			
		}
}

void led_set_all_RGBW(uint8_t r, uint8_t g, uint8_t b, uint8_t w) {
  for(uint_fast8_t i = 0; i < NUM_PIXELS; ++i) led_set_RGBW(i, r, g, b, w);
}

uint32_t hsl_to_rgb(uint8_t h, uint8_t s, uint8_t l) {
	if(l == 0) return 0;

	volatile uint8_t  r, g, b, lo, c, x, m;
	volatile uint16_t h1, l1, H;
	l1 = l + 1;
	if (l < 128)    c = ((l1 << 1) * s) >> 8;
	else            c = (512 - (l1 << 1)) * s >> 8;

	H = h * 6;              // 0 to 1535 (actually 1530)
	lo = H & 255;           // Low byte  = primary/secondary color mix
	h1 = lo + 1;

	if ((H & 256) == 0)   x = h1 * c >> 8;          // even sextant, like red to yellow
	else                  x = (256 - h1) * c >> 8;  // odd sextant, like yellow to green

	m = l - (c >> 1);
	switch(H >> 8) {       // High byte = sextant of colorwheel
	 case 0 : r = c; g = x; b = 0; break; // R to Y
	 case 1 : r = x; g = c; b = 0; break; // Y to G
	 case 2 : r = 0; g = c; b = x; break; // G to C
	 case 3 : r = 0; g = x; b = c; break; // C to B
	 case 4 : r = x; g = 0; b = c; break; // B to M
	 default: r = c; g = 0; b = x; break; // M to R
	}

	return (((uint32_t)r + m) << 16) | (((uint32_t)g + m) << 8) | ((uint32_t)b + m);
}

void BlinkLed(uint8_t r, uint8_t g, uint8_t b){
	for(uint8_t i = 0; i < 25 /* Change that to your amount of LEDs */; i++) {
			// Calculate color
			for(uint8_t j = 0; j<3;j++){
				
				led_set_RGB((i*3+j), r*(angle%2), g*(angle%2), b*(angle%2));
			}
			//if(i==0)printf("color:	%d\n", angle + (i * angle_difference));
		}
		// Write to LED
  	++angle;
		led_render();
		// Some delay
		HAL_Delay(30);
}

void ColorChange(void){
	//printf("angle:	%d\n", angle);
		for(uint8_t i = 0; i < 25 /* Change that to your amount of LEDs */; i++) {
			// Calculate color
			for(uint8_t j = 0; j<3;j++){
				
				uint32_t rgb_color = hsl_to_rgb(angle + (i * angle_difference), 255, 25);
				// Set color
				
				led_set_RGB((i*3+j), (rgb_color >> 16) & 0xFF, (rgb_color >> 8) & 0xFF, rgb_color & 0xFF);
				
			}
			//if(i==0)printf("color:	%d\n", angle + (i * angle_difference));
		}
		// Write to LED
  	//++angle;
		angle+=angle_difference;
		led_render();
		// Some delay
		HAL_Delay(30);
}

void Breath(uint8_t r, uint8_t g, uint8_t b){
	int red=1,green=1,blue=1;
	if(r==0)red=0;
	if(g==0)green=0;
	if(b==0)blue=0;
	for(uint8_t i = 0; i < 25 /* Change that to your amount of LEDs */; i++) {
			// Calculate color
			for(uint8_t j = 0; j<3;j++){
				
				led_set_RGB((i*3+j), r-(angle)*red, g-(angle)*green, b-(angle)*blue);
				//printf("%d, %d, %d \n", r-(angle), g-(angle), b-(angle));
			}
			
		}
		// Write to LED
		if(angle<0 || state==0){
  	angle+=1;
		state=0;
		}
		if(angle>55||state==1){
			angle-=1;
			state=1;
			
		}
		//printf("state:	%d, %d\n", state, angle);
		led_render();
		// Some delay
	//	HAL_Delay(30);
	
}

// Shuttle the data to the LEDs!
void led_render() {
  /*if(wr_buf_p != 0 || hdma_tim3_ch4_up.State != HAL_DMA_STATE_READY) {
    // Ongoing transfer, cancel!
    for(uint8_t i = 0; i < WR_BUF_LEN; ++i) wr_buf[i] = 0;
    wr_buf_p = 0;
    HAL_TIM_PWM_Stop_DMA(&htim3, TIM_CHANNEL_4);
    return;
  }*/
  // Ooh boi the first data buffer half (and the second!)
#if (NUM_BPP == 4) // SK6812
  for(uint_fast8_t i = 0; i < 8; ++i) {
    wr_buf[i     ] = PWM_LO << (((rgb_arr[0] << i) & 0x80) > 0);
    wr_buf[i +  8] = PWM_LO << (((rgb_arr[1] << i) & 0x80) > 0);
    wr_buf[i + 16] = PWM_LO << (((rgb_arr[2] << i) & 0x80) > 0);
    wr_buf[i + 24] = PWM_LO << (((rgb_arr[3] << i) & 0x80) > 0);
    wr_buf[i + 32] = PWM_LO << (((rgb_arr[4] << i) & 0x80) > 0);
    wr_buf[i + 40] = PWM_LO << (((rgb_arr[5] << i) & 0x80) > 0);
    wr_buf[i + 48] = PWM_LO << (((rgb_arr[6] << i) & 0x80) > 0);
    wr_buf[i + 56] = PWM_LO << (((rgb_arr[7] << i) & 0x80) > 0);
  }
#else // WS2812B
	
    HAL_TIM_PWM_Stop_DMA(&htim3, TIM_CHANNEL_4);
		//printf("value%d: ", wr_buf_p); 
	//for(int w=0; w<(3*10); w++) printf("%d ", rgb_arr[w]); 
	//printf("\n\r"); 
	//for(int w=0; w<(48); w++) printf("%d ", wr_buf[w]); 
  for(uint_fast8_t i = 0; i < 8; ++i) {
    wr_buf[i     ] = PWM_LO << (((rgb_arr[0] << i) & 0x80) > 0);
    wr_buf[i +  8] = PWM_LO << (((rgb_arr[1] << i) & 0x80) > 0);
    wr_buf[i + 16] = PWM_LO << (((rgb_arr[2] << i) & 0x80) > 0);
    wr_buf[i + 24] = PWM_LO << (((rgb_arr[3] << i) & 0x80) > 0);
    wr_buf[i + 32] = PWM_LO << (((rgb_arr[4] << i) & 0x80) > 0);
    wr_buf[i + 40] = PWM_LO << (((rgb_arr[5] << i) & 0x80) > 0);
  }
	
#endif // End SK6812 WS2812B case differentiation
HAL_TIM_PWM_Start_DMA(&htim3, TIM_CHANNEL_4, (uint32_t *)wr_buf, WR_BUF_LEN);
/*
//new

*/
  wr_buf_p = 2; // Since we're ready for the next buffer
}

void HAL_TIM_PWM_PulseFinishedHalfCpltCallback(TIM_HandleTypeDef *htim) {
  // DMA buffer set from LED(wr_buf_p) to LED(wr_buf_p + 1)
	if(htim==&htim3){
  if(wr_buf_p < NUM_PIXELS) {
    // We're in. Fill the even buffer
#if (NUM_BPP == 4) // SK6812
    for(uint_fast8_t i = 0; i < 8; ++i) {
      wr_buf[i     ] = PWM_LO << (((rgb_arr[4 * wr_buf_p    ] << i) & 0x80) > 0);
      wr_buf[i +  8] = PWM_LO << (((rgb_arr[4 * wr_buf_p + 1] << i) & 0x80) > 0);
      wr_buf[i + 16] = PWM_LO << (((rgb_arr[4 * wr_buf_p + 2] << i) & 0x80) > 0);
      wr_buf[i + 24] = PWM_LO << (((rgb_arr[4 * wr_buf_p + 3] << i) & 0x80) > 0);
    }
#else // WS2812B
    for(uint_fast8_t i = 0; i < 8; ++i) {
      wr_buf[i     ] = PWM_LO << (((rgb_arr[3 * wr_buf_p    ] << i) & 0x80) > 0);
      wr_buf[i +  8] = PWM_LO << (((rgb_arr[3 * wr_buf_p + 1] << i) & 0x80) > 0);
      wr_buf[i + 16] = PWM_LO << (((rgb_arr[3 * wr_buf_p + 2] << i) & 0x80) > 0);
    }
#endif // End SK6812 WS2812B case differentiation
    wr_buf_p++;
  } else if (wr_buf_p < NUM_PIXELS + 2) {
    // Last two transfers are resets. SK6812: 64 * 1.25 us = 80 us == good enough reset
  	//                               WS2812B: 48 * 1.25 us = 60 us == good enough reset
    // First half reset zero fill
    for(uint8_t i = 0; i < WR_BUF_LEN / 2; ++i) wr_buf[i] = 0;
    wr_buf_p++;
  }
}
}

void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim) {
  // DMA buffer set from LED(wr_buf_p) to LED(wr_buf_p + 1)
	if(htim==&htim3){
  if(wr_buf_p < NUM_PIXELS) {
    // We're in. Fill the odd buffer
#if (NUM_BPP == 4) // SK6812
    for(uint_fast8_t i = 0; i < 8; ++i) {
      wr_buf[i + 32] = PWM_LO << (((rgb_arr[4 * wr_buf_p    ] << i) & 0x80) > 0);
      wr_buf[i + 40] = PWM_LO << (((rgb_arr[4 * wr_buf_p + 1] << i) & 0x80) > 0);
      wr_buf[i + 48] = PWM_LO << (((rgb_arr[4 * wr_buf_p + 2] << i) & 0x80) > 0);
      wr_buf[i + 56] = PWM_LO << (((rgb_arr[4 * wr_buf_p + 3] << i) & 0x80) > 0);
    }
#else // WS2812B
    for(uint_fast8_t i = 0; i < 8; ++i) {
      wr_buf[i + 24] = PWM_LO << (((rgb_arr[3 * wr_buf_p    ] << i) & 0x80) > 0);
      wr_buf[i + 32] = PWM_LO << (((rgb_arr[3 * wr_buf_p + 1] << i) & 0x80) > 0);
      wr_buf[i + 40] = PWM_LO << (((rgb_arr[3 * wr_buf_p + 2] << i) & 0x80) > 0);
    }
#endif // End SK6812 WS2812B case differentiation
    wr_buf_p++;
  } else if (wr_buf_p < NUM_PIXELS + 2) {
    // Second half reset zero fill
    for(uint8_t i = WR_BUF_LEN / 2; i < WR_BUF_LEN; ++i) wr_buf[i] = 0;
    ++wr_buf_p;
  } else {
    // We're done. Lean back and until next time!
    ++wr_buf_p;
		if(wr_buf_p < NUM_PIXELS + 100){
	HAL_TIM_PWM_Stop_DMA(&htim3, TIM_CHANNEL_4);

			wr_buf_p = 0;
		}
   /* 
		//new
		
		*/
  }
	}
		
	 	if(htim == &htim16){
			stp = &stepper[0];
			stp->cnt++;
			if(stp->cnt>stp->steps)  { 
				HAL_TIM_PWM_Stop_IT(&htim16, TIM_CHANNEL_1);
			//stepCtrl(0);
				protocolActionCallback(ctrlStepperX,1);
				ismove_x=0;
				stp->cnt=0;
			}
	
   
		}/**/
		else if(htim == &htim17){
			stp = &stepper[1];
			stp->cnt++;
			
   
		}	
		if(htim == &htim14){
			
			/*stp = &stepper[2];
			stp->cnt++;
			if(stp->cnt>stp->steps)   {
				ismove_pill=0;
				HAL_TIM_PWM_Stop_IT(&htim14, TIM_CHANNEL_1);
				protocolActionCallback(rotatePillbox,temp_pill);
				stp->cnt=0;
			}*/
			//stepCtrl(2);
			
	  
		}			 

		if(htim == &htim1){
			stp = &stepper[3];
			stp->cnt++;
			if(stp->cnt>stp->steps)   HAL_TIM_PWM_Stop_IT(&htim1, TIM_CHANNEL_1);
			//stepCtrl(3);
			

		}
		if(htim == &htim15){
			
			//stepCtrl(4);
			
 
		}
		
}
