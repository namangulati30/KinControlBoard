#ifndef __REALTIMECLOCK_H
#define __REALTIMECLOCK_H
#include <main.h>

extern RTC_DateTypeDef gDate; 
extern RTC_TimeTypeDef gTime; 

struct rtc_time
{
int tm_sec;
int tm_min;
int tm_hour;
int tm_mday;
int tm_mon;
int tm_year;
int tm_wday;
};


void set_time (void) ;
void get_time(void);
void displaytime(void);



#endif
